<template lang="pug">
router-view
</template>

<script>
export default {
  name: "page-validators"
}
</script>
